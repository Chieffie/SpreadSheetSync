document.getElementById('import-btn').addEventListener('click', () => {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.csv, .xlsx';
  fileInput.onchange = (event) => {
    const file = event.target.files[0];
    const fileReader = new FileReader();

    if (file.name.endsWith('.csv')) {
      // Use PapaParse to parse CSV
      fileReader.onload = function (e) {
        const csvData = e.target.result;
        const parsedData = Papa.parse(csvData, { header: true }).data;
        renderHandsontable(parsedData);
      };
      fileReader.readAsText(file);
    } else if (file.name.endsWith('.xlsx')) {
      // Use SheetJS to parse Excel
      fileReader.onload = function (e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
        renderHandsontable(sheetData);
      };
      fileReader.readAsArrayBuffer(file);
    }
  };
  fileInput.click();
});

function renderHandsontable(data) {
  const container = document.getElementById('handsontable-container');
  new Handsontable(container, {
    data: data,
    colHeaders: true,
    rowHeaders: true,
    columnSorting: true,
    minSpareRows: 1,
    contextMenu: true
  });
}

document.getElementById('export-btn').addEventListener('click', () => {
  const hotInstance = Handsontable.getInstance(document.getElementById('handsontable-container'));
  const exportData = hotInstance.getData();

  // Export as CSV
  const csv = Papa.unparse(exportData);
  const csvBlob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const csvUrl = URL.createObjectURL(csvBlob);

  const downloadLink = document.createElement('a');
  downloadLink.href = csvUrl;
  downloadLink.download = 'exported_data.csv';
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
});
